-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2020 at 10:39 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int(11) NOT NULL,
  `room_no` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `address`, `phone`, `room_no`, `price`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Sakib Mohammed', '90 Housing Estate', 1670605075, 1, 1800, 0, '2020-02-23 04:37:59', '2020-02-23 06:24:11'),
(2, 'The Rock', 'Sylhet, Bangladesh', 1670605075, 2, 1700, 0, '2020-02-23 04:50:00', '2020-02-23 04:50:00'),
(3, 'Akash', 'Sylhet, Bangladesh', 1670605075, 3, 2500, 0, '2020-02-23 07:54:05', '2020-02-23 07:56:14'),
(4, 'The Doe', '90 Housing Estate', 1670605075, 1, 1300, 0, '2020-02-23 08:18:31', '2020-02-24 08:54:45'),
(5, 'Salman', 'Sylhet, Bangladesh', 16, 2, 2200, 0, '2020-02-23 08:23:59', '2020-02-23 08:29:52'),
(6, 'Jannath Motu', '90 Housing Estate', 1670605075, 4, 2500, 0, '2020-02-20 09:13:01', '2020-02-23 09:15:12'),
(7, 'Pondol', '90 Housing Estate', 1670605075, 7, 1800, 0, '2020-02-24 08:53:44', '2020-02-24 08:56:46'),
(8, 'Adil Rashid', '90 Housing Estate', 1670605075, 1, 1200, 0, '2020-02-24 08:57:44', '2020-02-24 09:12:51'),
(9, 'Vombol', '90 Housing Estate', 1670605075, 5, 1300, 0, '2020-02-24 08:58:13', '2020-02-24 09:11:29'),
(10, 'Vombol', '90 Housing Estate', 1670605075, 4, 1300, 0, '2020-02-24 08:59:15', '2020-02-24 09:11:14'),
(11, 'Sami', 'Sylhet, Bangladesh', 1670605075, 1, 1300, 0, '2020-02-24 09:13:48', '2020-02-24 09:17:45'),
(12, 'Sadi', 'Sylhet, Bangladesh', 1670605075, 2, 1700, 0, '2020-02-24 09:15:07', '2020-02-24 09:18:04'),
(13, 'Shuvon', '90 Housing Estate', 1670605075, 3, 1700, 0, '2020-02-24 09:16:03', '2020-02-24 09:21:33'),
(14, 'Akash', '90 Housing Estate', 1670605075, 4, 1700, 0, '2020-02-24 09:16:29', '2020-02-24 09:21:46'),
(15, 'The Rock', 'Sylhet, Bangladesh', 16, 5, 1700, 0, '2020-02-24 09:16:48', '2020-02-24 09:20:22'),
(16, 'The Rock', 'Sylhet, Bangladesh', 16, 6, 1700, 0, '2020-02-24 09:17:05', '2020-02-24 09:20:16'),
(17, 'Sami', 'Sylhet, Bangladesh', 1670605075, 6, 1200, 0, '2020-02-24 09:17:41', '2020-02-24 09:21:51'),
(18, 'Hasan', '90 Housing Estate', 1670605075, 5, 1700, 0, '2020-02-24 09:23:11', '2020-02-24 09:28:10'),
(19, 'The Rock', '90 Housing Estate', 1670605075, 5, 1300, 0, '2020-02-24 09:26:51', '2020-02-24 09:27:47'),
(20, 'Sakib', '90 Housing Estate', 1670605075, 1, 1300, 0, '2020-02-24 09:30:40', '2020-02-24 09:34:36'),
(21, 'Salman', '90 Housing Estate', 1670605075, 5, 1700, 0, '2020-02-24 09:35:00', '2020-02-24 09:35:29'),
(22, 'Vombol', 'Sylhet, Bangladesh', 1670605075, 1, 1800, 0, '2020-02-24 09:36:38', '2020-02-24 09:43:50'),
(23, 'Sami', 'Sylhet, Bangladesh', 1670605075, 6, 2500, 0, '2020-02-24 09:36:57', '2020-02-24 09:43:44'),
(24, 'The Doe', '90 Housing Estate', 1670605075, 5, 2200, 0, '2020-02-24 09:44:40', '2020-02-24 10:04:02'),
(25, 'One', '90 Housing Estate', 1670605075, 1, 1300, 0, '2020-02-24 09:46:53', '2020-02-27 12:46:51'),
(26, 'Two', '90 Housing Estate', 1670605075, 2, 1300, 0, '2020-02-24 09:47:23', '2020-02-27 12:48:02'),
(27, 'Three', '90 Housing Estate', 1670605075, 3, 1300, 0, '2020-02-24 09:47:48', '2020-02-27 12:46:39'),
(28, 'Hasan', 'Sylhet, Bangladesh', 1670605075, 7, 1200, 0, '2020-02-24 10:03:22', '2020-02-29 00:49:50'),
(29, 'Akash', '90 Housing Estate', 1670605075, 8, 1500, 0, '2020-02-29 00:47:55', '2020-03-04 09:03:13'),
(30, 'Sami', '90 Housing Estate', 1670605075, 1, 1200, 0, '2020-02-29 00:49:38', '2020-03-05 12:11:28'),
(31, 'Tomal', '90 Housing Estate', 1670605075, 4, 2800, 0, '2020-03-04 09:02:43', '2020-03-05 12:26:26'),
(32, 'Shuvon', 'Sylhet, Bangladesh', 1670605075, 13, 1000, 0, '2020-03-04 09:04:40', '2020-03-04 09:04:49'),
(33, 'Abul', '90 Housing Estate', 1670605075, 12, 1500, 0, '2020-03-05 12:12:15', '2020-03-05 12:12:20'),
(34, 'Jannath Motu', '90 Housing Estate', 1670605075, 1, 1500, 0, '2020-03-05 13:55:41', '2020-03-09 15:06:03'),
(35, 'Salman', '90 Housing Estate', 1670605075, 10, 1500, 0, '2020-03-05 13:56:51', '2020-03-05 14:59:36'),
(36, 'Shuvon', '90 Housing Estate', 1670605075, 7, 2200, 0, '2020-03-05 14:00:39', '2020-03-05 14:00:57');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(4, '2014_10_12_000000_create_users_table', 1),
(5, '2014_10_12_100000_create_password_resets_table', 1),
(6, '2020_02_22_190957_create_rooms_table', 1),
(7, '2020_02_23_095022_create_clients_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `room_no` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `people` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `room_no`, `price`, `people`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 2000, 2, 0, '2020-02-22 13:20:26', '2020-03-09 15:06:03'),
(2, 2, 2500, 3, 0, '2020-02-22 13:23:03', '2020-02-27 12:48:02'),
(3, 3, 2200, 3, 0, '2020-02-22 13:48:58', '2020-02-27 12:46:39'),
(4, 4, 3000, 5, 0, '2020-02-22 13:49:16', '2020-03-05 12:26:26'),
(5, 5, 2200, 3, 0, '2020-02-22 14:39:36', '2020-02-24 10:04:02'),
(6, 6, 2500, 3, 0, '2020-02-22 14:39:46', '2020-02-24 09:43:44'),
(7, 7, 1600, 2, 0, '2020-02-22 14:40:00', '2020-03-05 14:00:57'),
(8, 8, 1900, 3, 0, '2020-02-23 08:31:11', '2020-03-04 09:03:13'),
(9, 9, 2200, 3, 0, '2020-02-23 09:15:56', '2020-02-23 09:15:56'),
(10, 10, 3000, 3, 0, '2020-02-24 10:02:02', '2020-03-05 14:59:36'),
(11, 11, 2200, 2, 0, '2020-02-24 10:08:02', '2020-03-05 12:12:20'),
(13, 13, 2000, 3, 0, '2020-03-04 09:03:55', '2020-03-09 15:17:08'),
(120, 12, 1300, 2, 0, '2020-02-24 10:11:41', '2020-03-09 15:26:33'),
(121, 20, 1700, 2, 0, '2020-03-09 15:21:08', '2020-03-09 15:26:37');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `rooms_room_no_unique` (`room_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
